package com.example.final_project;

public enum InsuranceType {
    TYPE1,
    TYPE2
}
