package com.example.final_project;

public enum Category {
    GENERAL,
    OTHER
}
