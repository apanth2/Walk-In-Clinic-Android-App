# Walk-In-Clinic-Android-App
**My first ever android app!** Written in Java with android studio. This is a walk in clinic organizer/scheduling software.

This app was co-developed in my software engineering class with 4 other students. My main responsibillity was implementing the back end functionallity and database component.

## Running the App
The only way to run this app is to download and run the **RUN_ME.apk**

Once you run the app you'll need to create an account to sign in! Choose an employee or patient account and start exploring the app! Remember this isn't really built to work in reality. It was built for a school project...

You won't be able to run the app from the source code as I've removed my firebase credentials. 

## Known Bugs
LOTS, please don't be too hard on me :0

## DataBase Information
This project uses Google Firebase!

### Why Is Your Code So Bad??
Ya about that... So everything that I did in this project I learned as I created it. I have never programmed an android app before and well let's just say you'll be able to tell. The project was not planned or designed very well before development began and therefore there is a lot of redundancy and just horribly written code. Not to mention this project did have a strict deadline and a lot of rules and regulations. Anyways I think it's pretty good for a first try at android development!
